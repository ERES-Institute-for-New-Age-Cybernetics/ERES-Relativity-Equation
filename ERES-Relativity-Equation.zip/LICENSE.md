CARE Commons Attribution License v2.1

You are free to use, adapt, and distribute with attribution to Joseph A. Sprute and ERES Institute.